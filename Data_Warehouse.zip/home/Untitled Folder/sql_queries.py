import configparser


# CONFIG
config = configparser.ConfigParser()
config.read('dwh.cfg')

# DROP TABLES

staging_events_table_drop = "DROP TABLE IF EXISTS staging_events"
staging_songs_table_drop = "DROP TABLE IF EXISTS staging_songs"
songplay_table_drop = "DROP TABLE IF EXISTS song_plays "
user_table_drop = "DROP TABLE IF EXISTS users"
song_table_drop = "DROP TABLE IF EXISTS songs"
artist_table_drop = "DROP TABLE IF EXISTS artists"
time_table_drop = "DROP TABLE IF EXISTS time"

# CREATE TABLES

staging_events_table_create= ("""
                                CREATE TABLE IF NOT EXISTS staging_events(
    artist CHARACTER VARYING(200),
    auth CHARACTER VARYING(100),
    firstName CHARACTER VARYING(100),
    gender character,
    iteminSession INT,
    lastName CHARACTER VARYING(100),
    length decimal(10,5),
    level CHARACTER VARYING(25),
    location CHARACTER VARYING(200),
    method CHARACTER VARYING(25),
    page CHARACTER VARYING(25),
    registration DOUBLE PRECISION,
    sessionId INT,
    song CHARACTER VARYING(200),
    status INT,
    ts BIGINT,
    userAgent CHARACTER VARYING(200),
    userId INT
)
""")

staging_songs_table_create = ("""
CREATE TABLE "staging_songs" (
    "num_songs" INT,
    "artist_id" CHARACTER VARYING(100),
    "artist_latitude" decimal(10,5),
    "artist_longitude" decimal(10,5),
    "artist_location" CHARACTER VARYING(200),
    "artist_name" CHARACTER VARYING(200),
    "song_id" CHARACTER VARYING(100), 
    "title"CHARACTER VARYING(200), 
    "duration" decimal(10,5),
    "year" INT
)
""")(
                                )
""")

staging_songs_table_create = ("""
                                CREATE TABLE IF NOT EXISTS staging_songs(
                                )
""")

songplay_table_create = ("""
                        CREATE TABLE IF NOT EXISTS song_plays(
                        songplay_id IDENTITY(0,1) NOT NULL ,
                        start_time TIMESTAMP NOT NULL ,
                        user_id INT DISTKEY,
                        level VARCHAR NOT NULL,
                        song_id VARCHAR SORTKEY,
                        artist_id VARCHAR,
                        session_id INT NOT NULL, 
                        location VARCHAR,
                        user_agent TEXT
)""")
user_table_create = ("""
                    CREATE TABLE IF NOT EXISTS  users(
                    user_id  INT NOT NULL SORTKEY DISTKEY,
                    first_name  VARCHAR NOT NULL,
                    last_name  VARCHAR NOT NULL,
                    gender  CHAR(1),
                    level VARCHAR NOT NULL
)""")
song_table_create = ("""
                    CREATE TABLE  IF NOT EXISTS songs(
                    song_id VARCHAR NOT NULL SORTKEY,
                    title  VARCHAR NOT NULL,
                    artist_id  VARCHAR,
                    year INT,
                    duration FLOAT
)""")


artist_table_create = ("""
                      CREATE TABLE  IF NOT EXISTS artists(
                      artist_id VARCHAR NOT NULL SORTKEY,
                      name VARCHAR NOT NULL,
                      location VARCHAR,
                      latitude DECIMAL(9,6),
                      longitude DECIMAL(9,6)
)""")

time_table_create = ("""
                    CREATE TABLE IF NOT EXISTS  time(
                    start_time  TIMESTAMP NOT NULL SORTKEY,
                    hour INT NOT NULL ,
                    day INT NOT NULL ,
                    week INT NOT NULL ,
                    month INT NOT NULL ,
                    year INT NOT NULL ,
                    weekday VARCHAR NOT NULL
)""")
# STAGING TABLES

staging_events_copy = ("""
""").format()

staging_songs_copy = ("""
""").format()

# FINAL TABLES

songplay_table_insert = ("""
""")


user_table_insert = ("""
                         
""")
copy customer from 's3://awssampledbuswest2/ssbgz/customer' 
credentials 'aws_iam_role=<DWH_ROLE_ARN>'
gzip region 'us-west-2';

song_table_insert = ("""
s3://udacity-dend/song_data
credentials 'aws_iam_role=<DWH_ROLE_ARN>'
gzip region 'us-west-2';


artist_table_insert = 
time_table_insert = 


# QUERY LISTS

create_table_queries = [staging_events_table_create, staging_songs_table_create, songplay_table_create, user_table_create, song_table_create, artist_table_create, time_table_create]
drop_table_queries = [staging_events_table_drop, staging_songs_table_drop, songplay_table_drop, user_table_drop, song_table_drop, artist_table_drop, time_table_drop]
copy_table_queries = [staging_events_copy, staging_songs_copy]
insert_table_queries = [songplay_table_insert, user_table_insert, song_table_insert, artist_table_insert, time_table_insert]
