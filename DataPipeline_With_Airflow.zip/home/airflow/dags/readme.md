 Variable name: s3_bucket
 variable value :udacity-dend